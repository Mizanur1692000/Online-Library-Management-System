   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; <?php echo date('Y');?> Online Library Management System |<a href="https://phpgurukul.com/" target="_blank"  > Designed by : PHPGURUKUL</a> 
                </div>

            </div>
        </div>
    </section>